## Arrays-01 summary

```js

```
### More about arrays
text.

### Hands-on
Finish writing the [text]. Check the task as completed.
